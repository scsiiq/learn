#
#<?php die('Forbidden.'); ?>
#Date: 2019-11-29 08:05:58 UTC
#Software: Joomla Platform 13.1.0 Stable [ Curiosity ] 24-Apr-2013 00:00 GMT

#Fields: datetime	priority clientip	category	message
2019-11-29T08:05:58+00:00	INFO 37.19.6.169	joomlafailure	Пустой пароль не допускается
2019-12-02T08:11:14+00:00	INFO 37.19.6.169	joomlafailure	Логин или пароль введены неправильно, либо такой учётной записи ещё не существует.
